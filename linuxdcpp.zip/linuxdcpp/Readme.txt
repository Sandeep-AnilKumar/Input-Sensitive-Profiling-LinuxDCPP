Introduction
------------
LinuxDC++ is a Direct Connect client based on DC++. Utilizing the latest DC++ 
core, LinuxDC++ offers similar functionality to the Windows client like 
segmented downloading, TTH based file integrity, etc. with a GTK+ user 
interface. LinuxDC++ is free and open source software licensed under the GPL.

Direct Connect (DC) is a peer-to-peer file-sharing protocol. Clients connect to 
a central hub where they can chat or share files with one another. Users can 
view other users' list of shared files or search the hub for files.

This readme contains only the basic information. For more detailed instructions,
read the manual in the wiki:

http://openfacts.berlios.de/index-en.phtml?title=Ldcpp_Manual


Dependencies:
-------------
scons >= 0.96
pkg-config
g++ >= 4.1
gtk+-2.0 >= 2.12
gthread-2.0 >= 2.4
libglade-2.0 >= 2.4
pthread
zlib
libbz2
libssl
libboost
libnotify (optional)


Mac OS X (Darwin) Prerequisites
------------------------------------------
- XCode
- MacPorts
- Certain MacPorts ports:
   $ sudo /opt/local/bin/port install bzr scons pkgconfig libglade2 libnotify boost
- Hicolor Icon Theme (http://icon-theme.freedesktop.org/releases/)
- Explicitly specify MacPorts header directory so that the boost library is found:
   $ export CXXFLAGS=-I/opt/local/include


Compiling:
----------
$ cd /path/to/linuxdcpp
$ scons PREFIX=/path/to/install

Scons will output if something's missing in a clear and human-readable way.
The PREFIX parameter is the path that the program will be installed to. PREFIX
defaults to /usr/local, so it need only be specified if a different
directory is desired. Note the program doesn't have to be installed in order to
be ran. See the second part of the Running section for more details.

For compile options, type "scons --help".


Installing:
-----------
$ scons install

This command may need to be ran as root (sudo, su, etc.) depending upon
the PREFIX path that was supplied when compiling.


Running:
--------
If LinuxDC++ was installed using scons install, simply run the executable:

$ linuxdcpp

To run the program from the source directory instead of installing, first
navigate to that directory then run "./linuxdcpp". This is an important
point: scripts calling linuxdcpp in the source directory have to first cd to
that path in order to work (since it will look for pixmaps using the path
"./pixmaps" and this will fail if it's not in the correct directory).
Linuxdcpp no longer dynamically finds the location of the binary using
binreloc (since it wasn't portable).


Using:
------
Open the preferences and change the necessary options to your liking. If you're
behind a firewall or router, make sure to either set your connection type to
passive/firewall or configure the device to allow port forwarding. Read
http://www.dslreports.com/faq/dc/ for more information on this topic.

To minimize any character encoding issues, specify the default hub encoding on
the personal tab in preferences. This should be set to the character encoding
most commonly used in one's favorite hubs. Additionally, a per-hub character
encoding option can be found on the favorite hubs tab.


Translating:
------------
To help translate LinuxDC++, visit our translations page on Launchpad at
https://translations.launchpad.net/linuxdcpp. When adding translations for
your language, there are a few guidelines to be aware of. This project uses 
boost for its string formatting, so in some strings you will see %1%, %2%, etc.
format specifiers. These indicate the order of the variable in the original
string and are used in case translators need to reorder the variables for their 
locale.

Some strings from glade files use special Pango text markup that should not be
removed or modified. For example, in the string "<b>Auto-Drop</b>" the <b> and 
</b> is a special Pango markup that indicates the text within should be bold and
thus only the text 'Auto-Drop' should be translated.

Another important note is that some strings contain a '_' or underline character
that indicates the character directly after it is a mnemonic accelerator key. 
This means that users can use the keyboard to directly focus that item by
pressing ALT and the mnemonic accelerator key associated with that item. For
example, if the string is "Default _hub encoding:" then 'h' is the mnemonic
accelerator key and can be accessed by pressing ALT+h when that item is
displayed in the GUI. Please try to make sure that all strings that contain a
underline in the English msgid string also contain a corresponding underline in 
the translated string.

Another important note with the mnemonic accelerator key is to try to make the 
mnemonic accelerator key chosen unique for the part of the GUI in which the 
string is displayed, as best as you possibly can. For example, if you have 
"_Download Queue" and "Finished _Downloads" both visible in the GUI, then
when the user presses ALT+D it is ambiguous as to which they will select 
first since they have the same accelerator key. They may have to press the key 
repeatedly to focus on their intended item. Proper use of the mnemonic 
accelerator key will help keep LinuxDC++ accessible to people with disabilities 
and help speed up navigation for advanced users.


License:
--------
GNU GPL v2
See License.txt for details.


Contact:
--------
Website: https://launchpad.net/linuxdcpp
IRC: #linuxdc++@freenode.org

